package br.com.lab2.mvc.pv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pv2Application {

	public static void main(String[] args) {
		SpringApplication.run(Pv2Application.class, args);
	}

}
