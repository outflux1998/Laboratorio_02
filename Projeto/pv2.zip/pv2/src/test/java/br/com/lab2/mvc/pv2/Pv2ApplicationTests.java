package br.com.lab2.mvc.pv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
